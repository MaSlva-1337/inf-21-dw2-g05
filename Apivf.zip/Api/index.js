const express = require('express');
const bodyParser = require('body-parser')
const router = require('./routes/users.js'); 
const mysql = require('mysql');
const session = require("express-session");
const passport = require("passport");
const GitHubStrategy = require("passport-github2").Strategy;
const axios = require("axios");
const swaggerJSDoc = require("swagger-jsdoc");
const swaggerUi = require("swagger-ui-express");
const cors = require('cors');
const routes = require('./routes/users.js')

const GITHUB_CLIENT_ID = "54fb567bff89e1c5d06a";
const GITHUB_CLIENT_SECRET = "09417b17984f267617a4d0dd9596d02c16a05d4e";
const GITHUB_CALLBACK_URL = "http://localhost:3000/auth/github/callback";

const app = express();
const port = 3000;

/*const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'DesWeb2122',
    database: 'users',
    multipleStatements: true

})

db.connect((err) => {
    if (!err)
        console.log("G");
    else
        console.log("E");
})*/

/*app.get('/users', (req, res) => {

    //const sqlIns = "INSERT INTO users_tab (name, lastName, age) VALUES ('Jervásio','Silva',20);"
    let emp = req.body;
    var sql = "SELECT * FROM users_tab "

 
    db.query(sql, (err, result) => {
        res.send("Done");
    });
})*/

const passportOptions = {
    clientID: GITHUB_CLIENT_ID,
    clientSecret: GITHUB_CLIENT_SECRET,
    callbackURL: GITHUB_CALLBACK_URL,
};

const sessionOptions = {
    secret: "my top secret key",
    resave: false,
    saveUninitialized: true,
};


const auth = function (req, res, next) {
    if (req.isAuthenticated()) {
        return next();
    }

    res.redirect("/login");
};

//const swaggerDefinition = {

const swaggerDefinition = {
    openapi: "3.0.0",
    info: {
        title: "OAuth2.0_01",
        version: "1.0.0",
        description: "Example OAuth2.0 protected API",
        contact: { name: "Your name" },
    },
    servers: [{ url: "http://localhost:" + port }],
    components: {
        securitySchemes: {
            OAuth2Security: {
                type: "oauth2",
                flows: {
                    authorizationCode: {
                        authorizationUrl: "https://github.com/login/oauth/authorize",
                        tokenUrl: "https://github.com/login/oauth/access_token",
                        scopes: [],
                    },
                },
            },
        },
    },
    security: [{ OAuth2Security: [] }],
};

const options = {
    swaggerDefinition,
    apis: ["./docs/**/*.yaml"],
};

passport.serializeUser(function (user, done) { done(null, user); });
passport.deserializeUser(function (user, done) { done(null, user); });

passport.use(new GitHubStrategy(passportOptions,
    function (accessToken, refreshToken, profile, done) {
        profile.token = accessToken;
        return done(null, profile);
    })
);

const swaggerSpec = swaggerJSDoc(options);
app.get("/docs/swagger.json", (req, res) => res.json(swaggerSpec));
app.use("/docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));


app.use(session(sessionOptions));
app.use(passport.initialize());
app.use(passport.session());

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname + "/public")); //__dirname +

app.get("/", auth, function (req, res) {
    res.sendFile(__dirname + "/public/protected.html"); //__dirname +
});

app.get("/login", function (req, res) {
    res.sendFile(__dirname+ "/public/login.html"); //__dirname +
});

app.get("/logout", function (req, res) {
    req.logout();
    res.sendFile(__dirname + "/public/login.html"); //__dirname +
});

app.get("/auth/github/callback", passport.authenticate("github", { failureRedirect: "/login" }),
    function (req, res) {
        res.redirect("/");
    }
);

app.get("/auth/github", passport.authenticate("github", { scope: ["user:email"] }), function (req, res) { });

app.get("/me", auth, function (req, res) {
    res.json(req.user);
});

app.get("/githubme", auth, function (req, res) {
    const token = req.user.token;
    axios.get("https://api.github.com/user", { headers: { Authorization: `Bearer ${token}` } })
        .then(function (response) {
            res.json(response.data);
        }).catch(function (err) {
            res.json(err);
        });
});
 

app.use(bodyParser.json());

app.use('/users', routes);

app.get('/', (req, res) => res.send('Hello from homepage'));

app.listen(port, () => console.log(`Server running on port: ${port}`))