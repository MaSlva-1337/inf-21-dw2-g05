const mysql = require('mysql');
const db = mysql.createPool({
    host: 'localhost',
    port: 3306,
    user: 'root',
    password: 'DesWeb2122',
    database: 'users'
})

exports.pool = pool;