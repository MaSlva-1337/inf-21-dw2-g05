
const express = require('express');
const bodyParser = require('body-parser');
const router = express.Router();
const app = express();
const { uuid } = require('uuidv4');
let users = []

const mysql = require('mysql');
const db = mysql.createPool({
    host: 'localhost',
    port: 3306,
    user: 'root',
    password: 'DesWeb2122',
    database: 'usersdb'
})

// todas as rotas a começar por /users
//apresentar todos os utilizadores
router.get('/', (req, res) => {
    res.send(users);
});

//criar utilizadores
router.post('/', (req, res) => {
    const user = req.body;

    users.push({ ... user, id: uuid() });

    res.send(`O utilizador com o nome ${user.name} foi adicionado.`);
});

//utilizador por id
router.get('/:id', (req, res) => {
    const { id } = req.params;

    const findUser = users.find((user) => user.id === id);
    res.send(findUser);
});

// apagar utilizador por id
router.delete('/:id', (req, res) => {
    const { id } = req.params;

    users = users.filter((user) => user.id != id);

    res.send(`O utilizador com o id ${id} foi apagado.`);
});

// alterar parametros sobre o utilizador
router.patch('/:id', (req, res) => {
    const { id } = req.params;
    const { name, lastName, age } = req.body;
    const user = users.find((user) => user.id === id);

    if (name) user.name = name; 
    if (lastName) user.lastName = lastName;
    if (age) user.age = age;

    res.send(`O utilizador com o id ${id} foi atualizado.`);
});

const jsonParser = bodyParser.json();

router.get('/', (req, res, next) => {
    mysql.getConnection((error, conn) => {
        if (error) {
            return res.status(500).send({ error: error });
        }
        conn.query(
            'SELECT * FROM usersdb;',
            (error, result, fields) => {
                if (error) {
                    return res.status(500).send({ error: error });
                }
                return res.status(200).send({ resultado: result });
            }
        )
    });
});

router.post('/', jsonParser, (req, res, next) => {    
    mysql.getConnection((error, conn) => {
        if (error) {
            return res.status(500).send({ error: error });
        }
        conn.query(
            'INSERT INTO usersdb (id,name,lastName,age) VALUES (?, ?, ?, ?, ?, ?);', [req.body.id, req.body.name, req.body.lastName, req.body.age],
            (error, result, fields) => {
                conn.release();
                if (error) {
                    return res.status(500).send({ error: error, response: null });
                }
                return res.status(202).send({ mensagem: "Utilizador criado com sucesso" });
            }
        )
    });
});

router.patch('/', jsonParser, (req, res, next) => {    
    mysql.getConnection((error, conn) => {
        if (error) {
            return res.status(500).send({ error: error });
        }
        conn.query(
            `UPDATE usersdb 
                SET name           = ?, 
                    lastName       = ?, 
                    age            = ?,    
                    WHERE id = ?`, [req.body.name, req.body.lastName, req.body.age],
            (error, result, fields) => {
                conn.release();
                if (error) {
                    return res.status(500).send({ error: error, response: null });
                }
                return res.status(201).send({ mensagem: "Utilizador atualizado com sucesso" });
            }
        )
    });
});

router.delete('/:id', (req, res, next) => {
    const id = req.params;
    mysql.getConnection((error, conn) => {
        if (error) {
            return res.status(500).send({ error: error });
        }
        conn.query(
            `DELETE FROM usersdb WHERE id = ?`, [id],
            (error, result, fields) => {
                if (error) {
                    return res.status(500).send({ error: error });
                }
                return res.status(202).send({mensagem: "Utilizador removido com sucesso" });
            }
        )
    });
});

module.exports = router;