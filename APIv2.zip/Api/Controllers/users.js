
//import {v4 as uuidv4} from 'uuidv4';
/*
const v4 = require('uuid');
let users = []

apresentar os utilizadores

const getUsers = (req, res) => {
    res.send(users);
}

criar utilizadores
const criarUser = (req, res) => {
    const user = req.body;

    users.push({ ... user, id: uuidv4() });

    res.send(`O utilizador com o nome ${user.name} foi adicionado.`);
}

utilizador por id
const procurarUser = (req, res) => {
    const { id } = req.params;

    const findUser = users.find((user) => user.id === id);
    res.send(findUser);
}

apagar utilizador por id

const apagarUser = (req, res) => {
    const { id } = req.params;

    users = users.filter((user) => user.id != id);

    res.send(`O utilizador com o id ${id} foi apagado.`);
}

alterar parametros sobre o utilizador

const atualizarUser = (req, res) => {
    const { id } = req.params;
    const { name, lastName, age } = req.body;
    const user = users.find((user) => user.id === id);

    if (name) user.name = name; 
    if (lastName) user.lastName = lastName;
    if (age) user.age = age;

    res.send(`O utilizador com o id ${id} foi atualizado.`);
}

module.exports = {getUsers, criarUser, procurarUser, apagarUser, atualizarUser};*/