
const express = require('express');
/*const criarUser = require('../Controllers/users.js')
const getUsers = require('../Controllers/users.js')
const procurarUser = require('../Controllers/users.js')
const apagarUser = require('../Controllers/users.js')
const atualizarUser = require('../Controllers/users.js')*/

const router = express.Router();
const app = express();
const { uuid } = require('uuidv4');
let users = []

// todas as rotas a começar por /users
//apresentar todos os utilizadores
router.get('/', (req, res) => {
    res.send(users);
});

//criar utilizadores
router.post('/', (req, res) => {
    const user = req.body;

    users.push({ ... user, id: uuid() });

    res.send(`O utilizador com o nome ${user.name} foi adicionado.`);
});

//utilizador por id
router.get('/:id', (req, res) => {
    const { id } = req.params;

    const findUser = users.find((user) => user.id === id);
    res.send(findUser);
});

// apagar utilizador por id
router.delete('/:id', (req, res) => {
    const { id } = req.params;

    users = users.filter((user) => user.id != id);

    res.send(`O utilizador com o id ${id} foi apagado.`);
});

// alterar parametros sobre o utilizador
router.patch('/:id', (req, res) => {
    const { id } = req.params;
    const { name, lastName, age } = req.body;
    const user = users.find((user) => user.id === id);

    if (name) user.name = name; 
    if (lastName) user.lastName = lastName;
    if (age) user.age = age;

    res.send(`O utilizador com o id ${id} foi atualizado.`);
});

module.exports = router;