create database users_tab;
use users_tab;
create table users(user_id int primary key,
					 name  varchar(45),
                     lastName varchar(45),
                     age int);

INSERT INTO users (user_id,name,lastName,age) VALUES ('Joao','Silva',19);
INSERT INTO users (user_id,name,lastName,age) VALUES ('Jervásio','Silva',20);
