import express from "express";
import { v4 as uuidv4 } from "uuid";
import { criarUser, getUsers, procurarUser, apagarUser, atualizarUser } from "../Controllers/users.js";

const router = express.Router();

// todas as rotas a começar por /users
//apresentar todos os utilizadores
router.get('/', getUsers);

//criar utilizadores
router.post('/', criarUser );

//utilizador por id
router.get('/:id', procurarUser);

// apagar utilizador por id
router.delete('/:id', apagarUser);

// alterar parametros sobre o utilizador
router.patch('/:id', atualizarUser);

export default router;