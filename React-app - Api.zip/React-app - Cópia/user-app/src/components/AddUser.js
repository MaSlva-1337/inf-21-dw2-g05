import React from "react";

class AddUser extends React.Component {
    state = {
        name: "",
        lastName: "",
        age: "",
    };

    add = (e) => {
        e.preventDefault();
        if (this.state.name === "" || this.state.lastName === "" || this.state.age === "" ) {
            alert ("All fields are needed ");
            return;
        }
        this.props.addUserHandler(this.state);
        this.setState({name:"", lastName: "", age: ""});
    };

    

    render() {
        return (
            <div className="ui main">
                <h2>Add userrrrrr</h2>
                <h2>Add User</h2>
                <form className="ui form" onSubmit={this.add}>
                    <div className="field">
                        <label>Name</label>
                        <input type="text" name="name" placeholder="Name" value={this.state.name} onChange={(e) => this.setState({ name: e.target.value })}></input>
                    </div>
                    <div className="field">
                        <label>Last Name</label>
                        <input type="text" name="lastname" placeholder="lastName" value={this.state.lastName} onChange={(e) => this.setState({ lastName: e.target.value })}></input>
                    </div>
                    <div className="field">
                        <label>Age</label>
                        <input type="number" name="age" placeholder="age" value={this.state.age} onChange={(e) => this.setState({ age: e.target.value })}></input>
                    </div>
                    <button className="ui button blue">Add</button>
                </form>
            </div>
        );
    }

}

export default AddUser;