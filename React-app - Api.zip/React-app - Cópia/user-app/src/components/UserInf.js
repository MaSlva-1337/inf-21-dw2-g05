import React from "react";

const UserInf = (props) => {
    const {id, name, lastName, age} = props.user;
    return (
        <div className="item">
            <div className="content">
                <div className="header">{name}</div>
                <div>{lastName}</div>
                <div>{age}</div>
            </div>
            <div>
                <i className="trash alternate outline icon" style={{color:"red", marginTop: "7px"}} onClick={() => props.clickHandler(id)}></i>
            </div>
        </div>
    );

};

export default UserInf;