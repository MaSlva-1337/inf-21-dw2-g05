import React from "react";
import UserInf from "./UserInf";

const UserList = (props) => {
    console.log(props);

    const deleteUserHandler = (id) => {
        props.getUserId(id);
    };

    const renderUserList = props.users.map((user) => {
        return (
            <UserInf user={user} clickHandler={deleteUserHandler} key={user.id}></UserInf>
        );
    });
    return (
        <div className="ui celled list">
            {renderUserList}
        </div>
    );

};

export default UserList;