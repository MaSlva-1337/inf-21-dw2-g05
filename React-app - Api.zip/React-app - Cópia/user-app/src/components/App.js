import React, { useState, useEffect } from "react";
import './App.css';
import Header from "./Header.js";
import AddUser from "./AddUser.js";
import UserList from "./UserList.js";
import { uuid } from 'uuidv4';


function App() {
  const LOCAL_STORAGE_KEY = "users";
  const [users, setUsers] = useState([]);

  const addUserHandler = (user) => {
    console.log(user);
    //setUsers([...users, user]);
    setUsers([...users,{id: uuid(), ...user}]);
  };

  const removeUserHandler = (id) => {
    const newUserList = users.filter((user) => {
      return user.id !== id;
    });

    setUsers(newUserList);

  };

  useEffect(() => {
    const retrieveUser = JSON.parse(localStorage.getItem(LOCAL_STORAGE_KEY));
    if (retrieveUser) setUsers(retrieveUser);
    
    /*if (retrieveUser) {
      setUsers(retrieveUser);
    };*/
  }, []);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(users));
  }, [users]);

  return (
    <div className="ui container">
      <Header></Header>
      <AddUser addUserHandler={addUserHandler} />
      <UserList users={users} getUserId={removeUserHandler}></UserList>
    </div>
  );
}

export default App;
